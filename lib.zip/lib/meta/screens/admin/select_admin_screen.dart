import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:paxzadmin/app/constants/app_route_constants.dart';
import 'package:paxzadmin/app/constants/constants.dart';
import 'package:paxzadmin/app/constants/sizeconfig.dart';
import 'package:paxzadmin/meta/widgets/customappbar.dart';
import 'package:paxzadmin/meta/widgets/custombuttons.dart';
import 'package:paxzadmin/meta/widgets/customcontainer.dart';
import 'dart:developer' as devtools show log;

class AdminSelectionScreen extends StatefulWidget {
  const AdminSelectionScreen({super.key});

  @override
  State<AdminSelectionScreen> createState() => _AdminSelectionScreenState();
}

class _AdminSelectionScreenState extends State<AdminSelectionScreen> {
  bool isLoading = false;
  bool isSuccess = false;
  String? selectedAdmin;

  static const String userAdmin = 'User Admin';
  static const String psychologistAdmin = 'Psychologist Admin';

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    final buttonHeight = 50.0;
    final buttonBorder = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(8),
    );
    final textStyle = kPopinsSemiBold.copyWith(
      fontSize: SizeConfig.blockSizeHorizontal! * 4.5,
      fontWeight: FontWeight.w600,
    );

    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: BconstantColors.basecolor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: SizeConfig.screenHeight! * 0.12,
              child: const CustomAppbar(),
            ),
            SizedBox(height: SizeConfig.blockSizeVertical! * 1),
            customContainer(
              child: Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: SizeConfig.screenWidth! * 0.05,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: SizeConfig.blockSizeVertical! * 3),
                    Text(
                      "Select Your Admin",
                      style: kPopinsSemiBold.copyWith(
                        fontSize: SizeConfig.screenWidth! * 0.045,
                        color: BconstantColors.txt2color,
                      ),
                    ),
                    SizedBox(height: SizeConfig.blockSizeVertical! * 3),
                    _buildAdminButton(
                      label: userAdmin,
                      isSelected: selectedAdmin == userAdmin,
                      onTap: () {
                        setState(() {
                          selectedAdmin = userAdmin;
                          isLoading = false;
                          isSuccess = false;
                        });
                      },
                      buttonHeight: buttonHeight,
                      textStyle: textStyle,
                      border: buttonBorder,
                    ),
                    SizedBox(height: SizeConfig.blockSizeVertical! * 4),
                    _buildAdminButton(
                      label: psychologistAdmin,
                      isSelected: selectedAdmin == psychologistAdmin,
                      onTap: () {
                        setState(() {
                          selectedAdmin = psychologistAdmin;
                          isLoading = false;
                          isSuccess = false;
                        });
                      },
                      buttonHeight: buttonHeight,
                      textStyle: textStyle,
                      border: buttonBorder,
                    ),
                    SizedBox(height: SizeConfig.blockSizeVertical! * 8),
                    custombannerContainer(
                      height: SizeConfig.screenHeight! * 0.4,
                      width: SizeConfig.screenWidth!,
                      imagepath: 'assets/images/passw.png',
                    ),
                    SizedBox(height: SizeConfig.blockSizeVertical! * 3),
                    VerifyButton(
                      isLoading: isLoading,
                      isSuccess: isSuccess,
                      radius: 30,
                      height: SizeConfig.screenHeight! * 0.07,
                      width: SizeConfig.screenWidth!,
                      text1: "Next",
                      text2: "Loading...",
                      text3: "Done",
                      color: BconstantColors.buttonbgColor2,
                      textstyle: textStyle.copyWith(
                        color: BconstantColors.txt1color,
                      ),
                      voidCallback: () async {
                        devtools.log("Next button clicked");
                        if (selectedAdmin == null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Please select an admin type'),
                            ),
                          );
                          return;
                        }
                        setState(() {
                          isLoading = true;
                        });
                        await Future.delayed(const Duration(seconds: 3));
                        if (!mounted) return;
                        setState(() {
                          isLoading = false;
                          isSuccess = true;
                        });
                        await Future.delayed(const Duration(seconds: 2));
                        if (!mounted) return;
                        setState(() {
                          isSuccess = false;
                        });
                        if (selectedAdmin == userAdmin) {
                          context.pushNamed(
                              MyAppRouteConstants.useradminRouteName);
                        } else if (selectedAdmin == psychologistAdmin) {
                          context.pushNamed(
                              MyAppRouteConstants.doctoradminRouteName);
                        }
                      },
                    ),
                    SizedBox(height: SizeConfig.blockSizeVertical! * 2),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAdminButton({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
    required double buttonHeight,
    required TextStyle textStyle,
    required OutlinedBorder border,
  }) {
    return ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        minimumSize: Size(double.infinity, buttonHeight),
        backgroundColor:
            isSelected ? BconstantColors.buttonbgColor2 : Colors.white,
        side: const BorderSide(color: BconstantColors.buttonbgColor2),
        shape: border,
      ),
      child: Text(
        label,
        style: textStyle.copyWith(
          color: isSelected ? Colors.white : BconstantColors.buttonbgColor2,
        ),
      ),
    );
  }
}
