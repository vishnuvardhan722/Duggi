import 'package:flutter/material.dart';
import 'package:paxzadmin/app/constants/constants.dart';
import 'package:paxzadmin/app/constants/sizeconfig.dart';
import 'package:paxzadmin/meta/screens/admin/doctoradmin/funds_screen.dart';
import 'package:paxzadmin/meta/screens/admin/doctoradmin/overview_screen.dart';
import 'package:paxzadmin/meta/screens/admin/doctoradmin/psychologist_screen.dart';

class PsychologistAdminScreen extends StatefulWidget {
  const PsychologistAdminScreen({super.key});

  @override
  State<PsychologistAdminScreen> createState() =>
      _PsychologistAdminScreenState();
}

class _PsychologistAdminScreenState extends State<PsychologistAdminScreen>
    with TickerProviderStateMixin {
  late TabController tabController;

  @override
  void initState() {
    tabController = TabController(length: 3, vsync: this);
    super.initState();
  }

  final Shader linearGradient1 = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [
        BconstantColors.tabtxtColor,
        BconstantColors.txt2color,
      ]).createShader(Rect.largest);
  final Shader linearGradient2 = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [
        BconstantColors.tabtxtColor,
        BconstantColors.tabtxtColor,
      ]).createShader(Rect.largest);

  List topics = [
    "Overview",
    "Doctors",
    "Funds",
  ];

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      backgroundColor: BconstantColors.basecolor,
      body: SizedBox(
        child: Column(
          children: [
            SizedBox(
              height: SizeConfig.screenHeight! * 0.03,
            ),
            Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: SizeConfig.screenWidth! * 0.02,
                  vertical: SizeConfig.screenHeight! * 0.005),
              child: SizedBox(
                height: SizeConfig.screenHeight! * 0.092,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SizedBox(
                      height: SizeConfig.screenHeight! * 0.18,
                      width: SizeConfig.screenWidth! * 0.18,
                      child: Image.asset('assets/images/logo.jpg'),
                    ),
                    Text(
                      "Psychologist Admin",
                      style: kPopinsSemiBold.copyWith(
                          fontSize: SizeConfig.screenWidth! * 0.05,
                          color: BconstantColors.txt1color),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                          right: SizeConfig.screenWidth! * 0.05),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          // GestureDetector(
                          //   onTap: () {
                          //     // (context)
                          //     //     .pushNamed(MyAppRouteConstants.walletRoute);
                          //   },
                          //   child: Icon(
                          //     Icons.account_balance_wallet_rounded,
                          //     color: Colors.white,
                          //     size: SizeConfig.screenWidth! * 0.06,
                          //   ),
                          // ),
                          SizedBox(
                            width: SizeConfig.blockSizeHorizontal! * 7,
                          ),
                          GestureDetector(
                            onTap: () {
                              // (context).pushNamed(
                              //     MyAppRouteConstants.notificationRoute);
                            },
                            child: Icon(
                              Icons.notifications,
                              color: Colors.white,
                              size: SizeConfig.screenWidth! * 0.06,
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 7),
              child: SizedBox(
                height: SizeConfig.screenHeight! * 0.04,
                child: TabBar(
                    tabAlignment: TabAlignment.center,
                    padding: EdgeInsets.zero,
                    dividerColor: Colors.transparent,
                    labelPadding: EdgeInsets.symmetric(
                      horizontal: SizeConfig.blockSizeHorizontal! * 6,
                    ),
                    indicatorWeight: 3.7,
                    isScrollable: true,
                    indicatorSize: TabBarIndicatorSize.label,
                    indicator: const BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: BconstantColors.tabtxtColor,
                          width: 2.7,
                        ),
                      ),
                    ),
                    labelStyle: kPopinsMedium.copyWith(
                        fontSize: SizeConfig.blockSizeHorizontal! * 6,
                        foreground: Paint()..shader = linearGradient2),
                    unselectedLabelStyle: kPopinsMedium.copyWith(
                        fontSize: SizeConfig.blockSizeHorizontal! * 2,
                        foreground: Paint()..shader = linearGradient1),
                    unselectedLabelColor:
                        const Color.fromARGB(255, 219, 219, 219),
                    controller: tabController,
                    tabs: [
                      customtext(
                        text: topics[0],
                      ),
                      customtext(
                        text: topics[1],
                      ),
                      customtext(
                        text: topics[2],
                      ),
                      // customtext(
                      //   text: topics[3],
                      // ),

                      // customtext(
                      //   text: "Comments",
                      // ),
                    ]),
              ),
            ),
            Expanded(
              child: TabBarView(
                // physics: const NeverScrollableScrollPhysics(),
                controller: tabController,
                children: const [
                  OverviewScreen(),
                  PsychologistScreen(),
                  FundsScreen(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget customtext({text}) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Text(
      text,
      style: kPopinsSemiBold.copyWith(
          fontSize: SizeConfig.blockSizeHorizontal! * 4),
    ),
  );
}
